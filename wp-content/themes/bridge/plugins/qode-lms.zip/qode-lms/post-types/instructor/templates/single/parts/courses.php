<?php

echo bridge_qode_execute_shortcode( 'qode_course_list', $courses );